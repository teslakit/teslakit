# mw\_deltares

Model-Wrappers Deltares

Collection of python wrappers for Deltares numerical models.

This toolbox has been developed to ease numerical model integration with python code, it contains custom functions for numerical cases generation, execution, and output postprocessing.


## Main contents

[swan](./mw_deltares/swan/): SWAN numerical model toolbox 
- [io](./mw_deltares/swan/io.py): SWAN numerical model input/output operations
- [wrap](./mw_deltares/swan/wrap.py): SWAN numerical model python wrap 
- [geo](./mw_deltares/swan/geo.py): azimuth distance function
- [storms](./mw_deltares/swan/storms.py): storm parameters function 
- [plots](./mw_deltares/swan/plots/): plotting module 

[swash](./mw_deltares/swash/): SWASH numerical model toolbox 

TODO - imita la lista de swan para la libreria swash


## Documentation
SWAN numerical model detailed documentation can be found at: http://swanmodel.sourceforge.net/ 

- [SWAN install/compile manual](http://swanmodel.sourceforge.net/download/download.htm)
- [SWAN user manual](http://swanmodel.sourceforge.net/online_doc/swanuse/)


SWASH numerical model detailed documentation can be found at:  ...

TODO - pon la documentacion de SWASH que creas necesaria


## Install
- - -

The source code is currently hosted on GitLab at: https://gitlab.com/geoocean/bluemath/mw_deltares

### Install from sources

Install requirements. Navigate to the base root of [mw\_deltares](./) and execute:

```
   pip install -r requirements.txt
```

Then install py\_swan:

```
   python setup.py install

   # run pytest integration
   # python setup.py test
```


## Examples:
- - -

SWAN

- [demo 01 - STATIONARY](./scripts/swan_demo/demo_01_stat.py): stationary example
- [demo 02 - NON-STATIONARY](./scripts/swan_demo/demo_02_nonstat.py): non-stationary example 
- [demo 03 - VORTEX](./scripts/swan_demo/demo_03_nonstat_vortex.py): TCs Vortex Model example 

- [notebook demo - STATIONARY](./notebooks/swan_demo/demo_STAT_roi.ipynb): stationary notebook example with plots 

SWASH

TODO - programa y pon algunos ejemplos simples de swash 


## Notebook Examples:
- - -


## Authors:

* Nicolas Ripoll Cabarga
* Sara Ortega Van Vloten
* Alba Ricondo Cueva


## Thanks also to:

## License

This project is licensed under the MIT License - see the [license](./LICENSE.txt) file for details

