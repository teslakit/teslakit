# common fig parameters
_faspect = 1.618
_fsize = 9.8
_fdpi = 128

# TODO: figure parameters
_fntsize_label = 8
_fntsize_legend = 8
_fntsize_title = 8

