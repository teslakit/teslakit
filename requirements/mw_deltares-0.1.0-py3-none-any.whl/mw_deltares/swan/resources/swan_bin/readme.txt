swan_bin.exe file should be here
